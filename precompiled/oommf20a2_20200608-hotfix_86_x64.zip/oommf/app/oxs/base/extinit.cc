#include "ext.h"

/* End includes */


void OxsInitializeExt()
{
  Oxs_ExtRegistrationBlock regblk;
}
