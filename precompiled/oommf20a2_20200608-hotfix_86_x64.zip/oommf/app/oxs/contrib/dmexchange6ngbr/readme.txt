This package is designed to include Dzyaloshinskii-Moriya interactin (DMI) in OOMMF.
Please use the appropriate version, depending on the OOMMF release that you are using.

The file skyrmion.mif is a test file, to generate a skyrmion confined in a nanodot.

Please quote S. ROHART and A. THIAVILLE Phys. Rev. B 88, 184422 (2013) when using

Contact: stanislas.rohart@u-psud.fr
