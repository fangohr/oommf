/* FILE: arraywrapper.cc         -*-Mode: c++-*-
 *
 * This is an empty, unused file, just to quiet HP's CC pre-linker.
 *
 * Last modified on: $Date: 2007/03/21 01:10:16 $
 * Last modified by: $Author: donahue $
 */
